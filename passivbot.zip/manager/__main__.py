from cli import ManagerCLI
from sys import argv


if __name__ == "__main__":
    ManagerCLI().run(argv[1:])
